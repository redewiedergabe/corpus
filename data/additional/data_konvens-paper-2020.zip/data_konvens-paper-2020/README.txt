README for data_konvens-paper-2020

These are the exact training, validation and test corpora used to train and evaluate the taggers 
for direct, indirect and reported STWR described in

Brunner, Annelen / Tu, Ngoc Duyen Tanja / Weimer, Lukas / Jannidis, Fotis (2020): To BERT or
not to BERT – Comparing contextual embeddings in a deep learning architecture for the automatic
recognition of four types of speech, thought and writing representation, Proceedings of the 5th 
SwissText & 16th KONVENS Joint Conference.

The data is concatenated into a single file for each corpus. The value 'EOF' in the token column 
marks the end of a file. The corpora for direct, indirect and reported contain the same data, but 
have different labels (according to their STWR type).

All data in these files is part of corpus REDEWIEDERGABE (github.com/redewiedergabe/corpus).
There might be some slight discrepancies in the file names and annotations, as these files were
created before the final cleanup of corpus REDEWIEDERGABE.
